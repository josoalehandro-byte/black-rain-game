plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.orvane.blackrain"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.orvane.blackrain"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
